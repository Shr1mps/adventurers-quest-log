export { default as collect }    from './collect.js';
export { default as DOMPurify }  from './DOMPurify.js';