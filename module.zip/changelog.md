# Changelog

## [1.0.0] - 2025-11-22

### Branding
- **Module Name**: "Adventurer's Quest Log".
- **Module ID**: "adventurers-quest-log".
- **Author**: "Shr1mps".
- **Repository**: "https://github.com/Shr1mps/adventurers-quest-log".
