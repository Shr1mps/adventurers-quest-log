import { AQLHooks }  from './control/index.js';

// Initialize all hooks.
AQLHooks.init();